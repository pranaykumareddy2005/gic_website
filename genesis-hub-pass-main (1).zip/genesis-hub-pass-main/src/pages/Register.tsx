import { useState } from "react";
import Layout from "@/components/layout/Layout";
import { Helmet } from "react-helmet-async";
import { UserPlus, GraduationCap, Briefcase, Check, ChevronRight, QrCode, Mail, Phone, User } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { toast } from "sonner";
import { Link } from "react-router-dom";

type UserCategory = "student" | "professional";
type Step = 1 | 2 | 3;

const studentPasses = [
  {
    id: "student-day1",
    name: "Day 1 Pass",
    price: "₹1,000",
    duration: "27 Feb 2026",
    features: ["Knowledge Hub Access", "Expo Entry", "Networking", "Lunch & Refreshments"]
  },
  {
    id: "student-day2",
    name: "Day 2 Pass",
    price: "₹1,000",
    duration: "28 Feb 2026",
    features: ["Knowledge Hub Access", "Expo Entry", "Networking", "Lunch & Refreshments"]
  },
  {
    id: "student-both",
    name: "2-Day Pass",
    price: "₹1,500",
    duration: "27-28 Feb 2026",
    features: ["Full Event Access", "All Sessions", "Networking", "Meals Included"],
    popular: true
  },
  {
    id: "student-startup",
    name: "Startup Pass",
    price: "₹3,000",
    duration: "Both Days",
    features: ["Stall Space", "Investor Access", "Mentorship", "Full Event Access"]
  }
];

const professionalPasses = [
  {
    id: "pro-day1",
    name: "Day 1 Pass",
    price: "₹1,500",
    duration: "27 Feb 2026",
    features: ["Knowledge Hub Access", "Expo Entry", "Networking", "Lunch & Refreshments"]
  },
  {
    id: "pro-day2",
    name: "Day 2 Pass",
    price: "₹1,500",
    duration: "28 Feb 2026",
    features: ["Knowledge Hub Access", "Expo Entry", "Networking", "Lunch & Refreshments"]
  },
  {
    id: "pro-both",
    name: "2-Day Pass",
    price: "₹2,500",
    duration: "27-28 Feb 2026",
    features: ["Full Event Access", "All Sessions", "Networking", "Meals Included"],
    popular: true
  },
  {
    id: "pro-startup",
    name: "Startup Pass",
    price: "₹15,000",
    duration: "Both Days",
    features: ["Premium Stall", "Investor Meetings", "Mentorship", "Full Event Access"]
  },
  {
    id: "pro-vip",
    name: "VIP Pass",
    price: "₹5,000",
    duration: "Both Days",
    features: ["Priority Access", "Mentor Connect", "Premium Networking", "Exclusive Sessions"]
  }
];

const Register = () => {
  const [step, setStep] = useState<Step>(1);
  const [category, setCategory] = useState<UserCategory | null>(null);
  const [selectedPass, setSelectedPass] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: ""
  });

  const passes = category === "student" ? studentPasses : professionalPasses;

  const handleCategorySelect = (cat: UserCategory) => {
    setCategory(cat);
    setSelectedPass(null);
    setStep(2);
  };

  const handlePassSelect = (passId: string) => {
    setSelectedPass(passId);
    setStep(3);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.phone) {
      toast.error("Please fill in all fields");
      return;
    }
    toast.success("Registration submitted! You will receive a confirmation email shortly.");
  };

  const selectedPassData = passes.find(p => p.id === selectedPass);

  return (
    <>
      <Helmet>
        <title>Register - GIC 2026</title>
        <meta name="description" content="Register for Global Innovators Conclave 2026. Choose your pass type and complete your booking." />
      </Helmet>
      <Layout>
        {/* Hero Section */}
        <section className="bg-hero-gradient py-12 md:py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto">
              <Badge className="bg-primary/10 text-primary border-0 mb-4">
                <UserPlus className="w-3 h-3 mr-1" />
                Registration
              </Badge>
              <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                Register for <span className="text-gradient-blue">GIC 2026</span>
              </h1>
              <p className="text-muted-foreground">
                Complete your registration in 3 simple steps
              </p>
            </div>
          </div>
        </section>

        {/* Progress Steps */}
        <section className="py-8 border-b border-border">
          <div className="max-w-3xl mx-auto px-4">
            <div className="flex items-center justify-center gap-4">
              {[1, 2, 3].map((s) => (
                <div key={s} className="flex items-center">
                  <div 
                    className={`w-8 h-8 rounded-full flex items-center justify-center font-medium text-sm ${
                      step >= s 
                        ? "bg-primary text-primary-foreground" 
                        : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {step > s ? <Check className="w-4 h-4" /> : s}
                  </div>
                  <span className={`ml-2 text-sm hidden sm:inline ${step >= s ? "text-foreground" : "text-muted-foreground"}`}>
                    {s === 1 ? "Category" : s === 2 ? "Pass" : "Details"}
                  </span>
                  {s < 3 && <ChevronRight className="w-4 h-4 text-muted-foreground mx-4" />}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Step Content */}
        <section className="py-12 md:py-16">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Step 1: Category Selection */}
            {step === 1 && (
              <div className="max-w-2xl mx-auto">
                <h2 className="text-2xl font-bold text-foreground mb-6 text-center">
                  Select Your Category
                </h2>
                <p className="text-muted-foreground text-center mb-8">
                  This determines which passes are available to you and cannot be changed later.
                </p>
                <div className="grid sm:grid-cols-2 gap-6">
                  <button
                    onClick={() => handleCategorySelect("student")}
                    className="bg-card border-2 border-border hover:border-primary rounded-xl p-6 text-left transition-all card-hover"
                  >
                    <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center mb-4">
                      <GraduationCap className="w-7 h-7 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold text-foreground mb-2">Student</h3>
                    <p className="text-sm text-muted-foreground">
                      For college and school students with valid student ID
                    </p>
                  </button>

                  <button
                    onClick={() => handleCategorySelect("professional")}
                    className="bg-card border-2 border-border hover:border-primary rounded-xl p-6 text-left transition-all card-hover"
                  >
                    <div className="w-14 h-14 bg-accent/10 rounded-xl flex items-center justify-center mb-4">
                      <Briefcase className="w-7 h-7 text-accent" />
                    </div>
                    <h3 className="text-xl font-semibold text-foreground mb-2">Professional</h3>
                    <p className="text-sm text-muted-foreground">
                      For working professionals, entrepreneurs, and others
                    </p>
                  </button>
                </div>
              </div>
            )}

            {/* Step 2: Pass Selection */}
            {step === 2 && category && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-foreground">
                    Select Your Pass
                  </h2>
                  <Button variant="ghost" onClick={() => setStep(1)}>
                    ← Change Category
                  </Button>
                </div>
                <div className={`grid gap-6 ${category === "professional" ? "sm:grid-cols-2 lg:grid-cols-3" : "sm:grid-cols-2 lg:grid-cols-4"}`}>
                  {passes.map((pass) => (
                    <div 
                      key={pass.id}
                      className={`relative bg-card border-2 rounded-xl p-5 cursor-pointer transition-all card-hover ${
                        selectedPass === pass.id ? "border-primary" : "border-border hover:border-primary/50"
                      }`}
                      onClick={() => handlePassSelect(pass.id)}
                    >
                      {pass.popular && (
                        <Badge className="absolute -top-2 left-1/2 -translate-x-1/2 bg-primary">
                          Popular
                        </Badge>
                      )}
                      <h3 className="font-semibold text-foreground text-lg mb-1">{pass.name}</h3>
                      <p className="text-sm text-muted-foreground mb-3">{pass.duration}</p>
                      <p className="text-2xl font-bold text-primary mb-4">{pass.price}</p>
                      <ul className="space-y-2">
                        {pass.features.map((feature, i) => (
                          <li key={i} className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Check className="w-4 h-4 text-accent" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>

                {category === "student" && (
                  <div className="mt-8 bg-primary/5 border border-primary/20 rounded-xl p-5">
                    <h3 className="font-semibold text-foreground mb-2">School Student Pass</h3>
                    <p className="text-sm text-muted-foreground mb-3">
                      Special pass for school students (Classes 8-10) at ₹500
                    </p>
                    <Link to="/passes">
                      <Button variant="outline" size="sm">Learn More</Button>
                    </Link>
                  </div>
                )}
              </div>
            )}

            {/* Step 3: Details Form */}
            {step === 3 && selectedPassData && (
              <div className="max-w-2xl mx-auto">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-foreground">
                    Complete Registration
                  </h2>
                  <Button variant="ghost" onClick={() => setStep(2)}>
                    ← Change Pass
                  </Button>
                </div>

                {/* Selected Pass Summary */}
                <div className="bg-primary/5 border border-primary/20 rounded-xl p-5 mb-8">
                  <div className="flex justify-between items-start">
                    <div>
                      <Badge variant="outline" className="mb-2">
                        {category === "student" ? "Student" : "Professional"}
                      </Badge>
                      <h3 className="font-semibold text-foreground text-lg">{selectedPassData.name}</h3>
                      <p className="text-sm text-muted-foreground">{selectedPassData.duration}</p>
                    </div>
                    <p className="text-2xl font-bold text-primary">{selectedPassData.price}</p>
                  </div>
                </div>

                {/* Registration Form */}
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <Label htmlFor="name" className="flex items-center gap-2 mb-2">
                      <User className="w-4 h-4" />
                      Full Name
                    </Label>
                    <Input 
                      id="name" 
                      name="name"
                      placeholder="Enter your full name"
                      value={formData.name}
                      onChange={handleInputChange}
                    />
                  </div>

                  <div>
                    <Label htmlFor="email" className="flex items-center gap-2 mb-2">
                      <Mail className="w-4 h-4" />
                      Email Address
                    </Label>
                    <Input 
                      id="email" 
                      name="email"
                      type="email"
                      placeholder="Enter your email"
                      value={formData.email}
                      onChange={handleInputChange}
                    />
                  </div>

                  <div>
                    <Label htmlFor="phone" className="flex items-center gap-2 mb-2">
                      <Phone className="w-4 h-4" />
                      Mobile Number
                    </Label>
                    <Input 
                      id="phone" 
                      name="phone"
                      type="tel"
                      placeholder="Enter your mobile number"
                      value={formData.phone}
                      onChange={handleInputChange}
                    />
                  </div>

                  <Button type="submit" className="w-full" size="lg">
                    Proceed to Payment
                  </Button>
                </form>

                {/* QR Info */}
                <div className="mt-8 flex items-center gap-4 p-4 bg-muted/50 rounded-xl">
                  <QrCode className="w-10 h-10 text-primary" />
                  <div>
                    <p className="font-medium text-foreground">QR-Based Entry</p>
                    <p className="text-sm text-muted-foreground">
                      You'll receive a unique QR code for event entry after payment
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>
      </Layout>
    </>
  );
};

export default Register;
