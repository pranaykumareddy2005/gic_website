import Layout from "@/components/layout/Layout";
import { Helmet } from "react-helmet-async";
import { useState } from "react";
import { Check, ArrowRight, QrCode, Shield, CreditCard } from "lucide-react";
import { Button } from "@/components/ui/button";

const Passes = () => {
  const [category, setCategory] = useState<"student" | "professional">("student");

  const studentPasses = [
    {
      name: "Student Delegation Pass",
      duration: "1 Day",
      price: "₹1,000",
      features: [
        "Access to Knowledge Hub sessions",
        "Entry to BusiTech Expo",
        "Mini events participation",
        "Networking opportunities",
        "Certificate of participation",
      ],
    },
    {
      name: "Student Delegation Pass",
      duration: "2 Days",
      price: "₹1,500",
      popular: true,
      features: [
        "Full 2-day event access",
        "All Knowledge Hub sessions",
        "Complete BusiTech Expo access",
        "All mini events",
        "Enhanced networking",
        "Certificate of participation",
      ],
    },
    {
      name: "Student Startup Pass",
      duration: "Stall Access",
      price: "₹3,000",
      features: [
        "Dedicated stall space",
        "Full 2-day event access",
        "Investor exposure",
        "Mentor feedback sessions",
        "Collaboration opportunities",
        "Certificate & recognition",
      ],
    },
  ];

  const professionalPasses = [
    {
      name: "Professional Delegation Pass",
      duration: "1 Day",
      price: "₹1,500",
      features: [
        "Access to Knowledge Hub sessions",
        "Entry to BusiTech Expo",
        "Professional networking",
        "Industry insights",
        "Certificate of participation",
      ],
    },
    {
      name: "Professional Delegation Pass",
      duration: "2 Days",
      price: "₹2,500",
      popular: true,
      features: [
        "Full 2-day event access",
        "All Knowledge Hub sessions",
        "Complete expo access",
        "Extended networking",
        "Industry connections",
        "Certificate of participation",
      ],
    },
    {
      name: "Professional Startup Pass",
      duration: "Stall Access",
      price: "₹15,000",
      features: [
        "Premium stall space",
        "Full 2-day event access",
        "Direct investor meetings",
        "Pitch opportunities",
        "Media exposure",
        "Certificate & recognition",
      ],
    },
    {
      name: "VIP Pass",
      duration: "Premium Access",
      price: "₹5,000",
      features: [
        "Priority session access",
        "Direct mentor interactions",
        "Mentor contact details access",
        "Premium networking zone",
        "VIP lounge access",
        "Exclusive certificate",
      ],
    },
  ];

  const passes = category === "student" ? studentPasses : professionalPasses;

  return (
    <>
      <Helmet>
        <title>Passes - GIC 2026 | Global Innovators Conclave</title>
        <meta name="description" content="Get your pass for GIC 2026. Choose from Student, Professional, Startup, VIP, or School passes." />
      </Helmet>
      <Layout>
        {/* Hero */}
        <section className="py-16 bg-muted/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
              Event Passes
            </h1>
            <p className="text-muted-foreground text-lg max-w-2xl">
              Choose your pass based on your category and get instant QR-code based entry
            </p>
          </div>
        </section>

        {/* Category Toggle */}
        <section className="py-8 bg-background border-b border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-center">
              <div className="inline-flex bg-muted rounded-full p-1">
                <button
                  onClick={() => setCategory("student")}
                  className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${
                    category === "student"
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  Student
                </button>
                <button
                  onClick={() => setCategory("professional")}
                  className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${
                    category === "professional"
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  Professional
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Passes Grid */}
        <section className="py-16 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className={`grid gap-6 ${category === "professional" ? "md:grid-cols-2 lg:grid-cols-4" : "md:grid-cols-3"}`}>
              {passes.map((pass, index) => (
                <div
                  key={index}
                  className={`relative bg-card rounded-2xl p-6 border ${
                    pass.popular ? "border-primary" : "border-border"
                  } hover:border-primary/50 transition-all`}
                >
                  {pass.popular && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-xs font-medium px-3 py-1 rounded-full">
                      Most Popular
                    </div>
                  )}
                  <div className="mb-4">
                    <h3 className="font-semibold text-foreground">{pass.name}</h3>
                    <p className="text-sm text-primary">{pass.duration}</p>
                  </div>
                  <p className="text-3xl font-bold text-foreground mb-6">{pass.price}</p>
                  <ul className="space-y-3 mb-6">
                    {pass.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm">
                        <Check className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                        <span className="text-muted-foreground">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button
                    className={`w-full rounded-full ${
                      pass.popular
                        ? "bg-primary hover:bg-primary/90 text-primary-foreground"
                        : "bg-muted hover:bg-muted/80 text-foreground"
                    }`}
                  >
                    Register Now
                  </Button>
                </div>
              ))}
            </div>

            {/* School Pass */}
            <div className="mt-12">
              <h2 className="font-display text-xl font-semibold text-foreground mb-6 text-center">
                For School Students
              </h2>
              <div className="max-w-sm mx-auto bg-card rounded-2xl p-6 border border-border">
                <h3 className="font-semibold text-foreground">School Student Pass</h3>
                <p className="text-sm text-primary mb-4">Classes 8-10</p>
                <p className="text-3xl font-bold text-foreground mb-6">₹500</p>
                <ul className="space-y-3 mb-6">
                  {[
                    "Masterminds Congregation access",
                    "Innovation showcase platform",
                    "Mentor interactions",
                    "Early entrepreneurship exposure",
                    "Certificate of participation",
                  ].map((feature, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm">
                      <Check className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                      <span className="text-muted-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button className="w-full rounded-full bg-primary hover:bg-primary/90 text-primary-foreground">
                  Register Now
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* QR Entry System */}
        <section className="py-16 bg-muted/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="font-display text-2xl font-semibold text-foreground mb-10 text-center">
              QR-Code Based Entry System
            </h2>
            <div className="grid md:grid-cols-3 gap-8 max-w-3xl mx-auto">
              {[
                { icon: CreditCard, title: "Instant Booking", desc: "Complete payment and receive your unique QR code instantly" },
                { icon: QrCode, title: "Digital Pass", desc: "Access your QR code anytime through your dashboard" },
                { icon: Shield, title: "Secure Entry", desc: "Quick verification prevents duplicate or unauthorized access" },
              ].map((step, index) => (
                <div key={index} className="text-center">
                  <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <step.icon className="w-7 h-7 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">{step.title}</h3>
                  <p className="text-muted-foreground text-sm">{step.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </Layout>
    </>
  );
};

export default Passes;
