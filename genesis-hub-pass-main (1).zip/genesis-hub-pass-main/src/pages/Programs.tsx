import Layout from "@/components/layout/Layout";
import knowledgeBubbleImg from "@/assets/knowledge-bubble.jpeg";
import { Helmet } from "react-helmet-async";
import { ArrowUpRight, Calendar, CheckCircle2, Clock, Users, Trophy, Target, Code2, Briefcase, TrendingUp, GraduationCap, Lightbulb, Cpu, Rocket, Building } from "lucide-react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const programs = [
  {
    id: "alpha-to-infinity",
    title: "Alpha to Infinity",
    subtitle: "30-Hour Hiring Hackathon",
    type: "FREE",
    mode: "IN-PERSON",
    date: "27-28 Feb 2026",
    duration: "30 Hours",
    participants: "360 Selected Participants",
    icon: Code2,
    color: "from-violet-500 to-purple-600",
    description: "A 30-hour intensive hiring hackathon designed to identify and nurture exceptional technical talent across multiple technology domains. Teams of 6 compete across Frontend, Backend, DevOps & AI streams with direct hiring opportunities from partner companies.",
    image: "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=800&h=400&fit=crop",
    features: [
      "360 participants selected via LinkedIn, CV & GitHub review",
      "60 industry mentors across 4 technology streams",
      "Teams of 6 with mandatory cross-stream representation",
      "Problem statements from hiring companies",
      "Direct internship & PPO opportunities",
      "Top 10 teams advance to final presentations",
    ],
    schedule: [
      { time: "09:30 - 10:00", activity: "Inauguration", day: 1 },
      { time: "10:00 - 10:30", activity: "Problem Statement Announcement", day: 1 },
      { time: "11:00 - 18:00", activity: "Sprint 1 (7 hours)", day: 1 },
      { time: "18:00 - 19:00", activity: "Mentor Checking - Milestone 1", day: 1 },
      { time: "20:00 - 00:00", activity: "Sprint 2 (4 hours)", day: 1 },
      { time: "00:00 - 01:00", activity: "Campfire & Networking", day: 2 },
      { time: "01:00 - 10:00", activity: "Sprint 3 (10 hours)", day: 2 },
      { time: "10:00 - 12:00", activity: "Final Evaluation & Top 10 Selection", day: 2 },
      { time: "13:00 - 15:00", activity: "Final Presentations", day: 2 },
      { time: "16:00", activity: "Prize Distribution", day: 2 },
    ],
    streams: [
      { name: "Frontend Development", priority: 1 },
      { name: "Backend Development", priority: 2 },
      { name: "DevOps & Cloud Infrastructure", priority: 3 },
      { name: "Artificial Intelligence", priority: 4 },
    ],
    partners: ["Hack2Skill", "Unstop", "Google Cloud", "AWS", "Microsoft Azure"],
  },
  {
    id: "business-tech-expo",
    title: "Business Tech Expo",
    subtitle: "Startup & Student Exhibition",
    type: "PAID",
    mode: "IN-PERSON",
    date: "27-28 Feb 2026",
    duration: "2 Days",
    participants: "50 Exhibitors",
    icon: Briefcase,
    color: "from-blue-500 to-indigo-600",
    description: "A multi-day showcase for startups and student projects to present their MVPs and prototypes, with professional evaluation and potential investor connections. Selected exhibitors advance to the Investor Pitching Summit.",
    image: "https://images.unsplash.com/photo-1559136555-9303baea8ebd?w=800&h=400&fit=crop",
    features: [
      "20 Professional Startup exhibits",
      "30 Student Project exhibits",
      "60% Business Potential evaluation weight",
      "40% Customer Validation evaluation weight",
      "Top performers advance to Investor Pitching",
      "Mini workshops and technical sessions",
    ],
    schedule: [
      { time: "08:30 - 11:00", activity: "Stall Setup & Inauguration", day: 1 },
      { time: "11:00 - 15:00", activity: "Live Exhibition", day: 1 },
      { time: "15:00 - 17:00", activity: "Mini Workshops", day: 1 },
      { time: "09:30 - 11:00", activity: "Expert Evaluation", day: 2 },
      { time: "11:00 - 16:00", activity: "Investor Pitch (Selected Teams)", day: 2 },
      { time: "16:00", activity: "Prize Distribution", day: 2 },
    ],
    evaluation: [
      { criteria: "Business Model & Strategy", weight: "30%" },
      { criteria: "Market Validation", weight: "30%" },
      { criteria: "User Acceptance Testing", weight: "25%" },
      { criteria: "Market Demand Verification", weight: "15%" },
    ],
  },
  {
    id: "investor-pitching-summit",
    title: "Investor Pitching Summit",
    subtitle: "Pre-Seed & Seed Stage Funding",
    type: "FREE",
    mode: "IN-PERSON",
    date: "27-28 Feb 2026",
    duration: "2 Days",
    participants: "63 Teams",
    icon: TrendingUp,
    color: "from-emerald-500 to-teal-600",
    description: "A premier platform for entrepreneurs to present their startups to potential investors, with separate tracks for student ventures (pre-seed) and professional startups (seed stage). Registration deadline: February 22.",
    image: "https://images.unsplash.com/photo-1553028826-f4804a6dba3b?w=800&h=400&fit=crop",
    features: [
      "35 Student teams (Pre-Seed track)",
      "28 Professional teams (Seed track)",
      "5-minute pitch + Q&A format",
      "Expert investor panels",
      "Funding opportunities up to ₹10 Crore",
      "Results announced within 3 working days",
    ],
    tracks: [
      {
        name: "Student Track (Pre-Seed)",
        slots: 35,
        pitchDuration: "5 minutes",
        qaDuration: "5 minutes",
        totalTime: "12 minutes",
      },
      {
        name: "Professional Track (Seed)",
        slots: 28,
        pitchDuration: "5 minutes",
        qaDuration: "10 minutes",
        totalTime: "17 minutes",
      },
    ],
    schedule: [
      { time: "09:00 - 10:00", activity: "Inauguration", day: 1 },
      { time: "13:00 - 16:00", activity: "Student Pitching (15 teams)", day: 1 },
      { time: "13:00 - 17:00", activity: "Professional Pitching (14 teams)", day: 1 },
      { time: "10:00 - 12:00", activity: "Student Pitching (10 teams)", day: 2 },
      { time: "13:30 - 15:30", activity: "Student Pitching (10 teams)", day: 2 },
      { time: "10:00 - 15:30", activity: "Professional Pitching (14 teams)", day: 2 },
    ],
  },
  {
    id: "mastermind-congregation",
    title: "Mastermind Congregation",
    subtitle: "School Innovators Program",
    type: "PAID",
    mode: "HYBRID",
    date: "Jan - Feb 2026",
    duration: "Multi-Phase",
    participants: "1,200 Students",
    icon: GraduationCap,
    color: "from-amber-500 to-orange-600",
    description: "A multi-phase initiative to foster entrepreneurial mindset and startup culture among school students (8th-9th grade), with training, mentorship, and a competitive finale with ₹1.5 Lakh prize pool.",
    image: "https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?w=800&h=400&fit=crop",
    features: [
      "1,200 students from participating schools",
      "Teams of 3 members",
      "Expert training by SMEC faculty",
      "Multi-year school collaboration framework",
      "Top 100 teams compete in Grand Finale",
      "₹1,50,000 prize pool",
    ],
    phases: [
      { phase: "Phase 1", date: "January 20", activity: "Entrepreneurship 101 Workshop", participants: "1,200 students" },
      { phase: "Phase 2", date: "February 2-4", activity: "Expert Training Sessions", topics: "Pitching, Business Model, Market Validation" },
      { phase: "Phase 3", date: "February 10-20", activity: "School-Based Screening", outcome: "Top teams selected per school" },
      { phase: "Phase 4", date: "February 22", activity: "Final Results Announcement", outcome: "100 teams advance" },
      { phase: "Phase 5", date: "February 27-28", activity: "Grand Finale at SMEC", prize: "₹1,50,000" },
    ],
  },
  {
    id: "knowledge-bubble",
    title: "Knowledge Bubble",
    subtitle: "Premier Deep-Tech Conclave",
    type: "FREE",
    mode: "HYBRID",
    date: "27-28 Feb 2026",
    duration: "2 Days",
    participants: "2,700 Capacity",
    icon: Lightbulb,
    color: "from-pink-500 to-rose-600",
    description: "A premier two-day platform bringing together policymakers, industry leaders, innovators, scientists, and entrepreneurs to discuss national strategy, regulatory frameworks, and technological advancement across cutting-edge domains.",
    image: knowledgeBubbleImg,
    features: [
      "Main Auditorium: 1,300 capacity",
      "Technology Track A & B: 700 each",
      "Keynote sessions with industry leaders",
      "Panel discussions on 9 deep-tech domains",
      "Policy & government representation",
      "Networking and exhibition areas",
    ],
    focusAreas: [
      "Artificial Intelligence & ML",
      "Quantum Technologies",
      "Robotics & Autonomous Systems",
      "Space & Defence Technologies",
      "Biotechnology & Life Sciences",
      "Semiconductors & Electronics",
      "Data Centers & Infrastructure",
      "Advanced Materials & Nanotech",
      "Climate & Sustainability",
    ],
    venues: [
      { name: "Main Auditorium", block: "MG Block", capacity: 1300 },
      { name: "Technology Track A", block: "SCB Block", capacity: 700 },
      { name: "Technology Track B", block: "SCB Block", capacity: 700 },
    ],
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 }
};

const Programs = () => {
  return (
    <>
      <Helmet>
        <title>Programs - GIC 2026 | Global Innovators Conclave</title>
        <meta name="description" content="Explore the comprehensive event portfolio at GIC 2026: Alpha to Infinity Hackathon, Business Tech Expo, Investor Pitching Summit, Mastermind Congregation, and Knowledge Bubble Conclave." />
      </Helmet>
      <Layout>
        {/* Hero */}
        <section className="py-20 bg-gic-dark relative overflow-hidden">
          <motion.div
            className="absolute top-0 right-0 w-[600px] h-[600px] bg-gradient-to-bl from-primary/20 to-transparent rounded-full blur-3xl"
            animate={{ opacity: [0.3, 0.5, 0.3] }}
            transition={{ duration: 5, repeat: Infinity }}
          />
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <p className="text-primary font-semibold text-sm tracking-wider uppercase mb-4">
                Comprehensive Event Portfolio
              </p>
              <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
                Programs & <span className="text-gradient-purple">Tracks</span>
              </h1>
              <p className="text-white/70 text-lg max-w-3xl">
                A multi-layered approach to innovation ecosystem development - spanning technical talent identification, 
                startup validation and commercialization, youth entrepreneurship cultivation, and policy dialogue.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Programs List */}
        <section className="py-20 bg-gic-dark">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              variants={containerVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="space-y-16"
            >
              {programs.map((program, index) => (
                <motion.div
                  key={program.id}
                  variants={itemVariants}
                  className="bg-white/5 backdrop-blur-sm rounded-3xl border border-white/10 overflow-hidden hover:border-primary/30 transition-all duration-500"
                >
                  {/* Header with Image */}
                  <div className="relative h-72 lg:h-80">
                    <img
                      src={program.image}
                      alt={program.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-gic-dark via-gic-dark/50 to-transparent" />
                    
                    {/* Badges */}
                    <div className="absolute top-6 left-6 flex gap-2">
                      <span className="text-xs px-4 py-1.5 rounded-full bg-primary text-white font-semibold">
                        {program.type}
                      </span>
                      <span className="text-xs px-4 py-1.5 rounded-full bg-white/20 backdrop-blur-sm text-white font-medium border border-white/20">
                        {program.mode}
                      </span>
                    </div>

                    {/* Icon */}
                    <div className="absolute top-6 right-6">
                      <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${program.color} flex items-center justify-center shadow-xl`}>
                        <program.icon className="w-8 h-8 text-white" />
                      </div>
                    </div>

                    {/* Title on Image */}
                    <div className="absolute bottom-6 left-6 right-6">
                      <h2 className="font-display text-3xl md:text-4xl font-bold text-white mb-2">
                        {program.title}
                      </h2>
                      <p className="text-primary font-medium text-lg">{program.subtitle}</p>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-8 lg:p-10">
                    {/* Quick Stats */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                      <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                        <Calendar className="w-5 h-5 text-primary mb-2" />
                        <p className="text-white/60 text-xs">Date</p>
                        <p className="text-white font-semibold">{program.date}</p>
                      </div>
                      <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                        <Clock className="w-5 h-5 text-primary mb-2" />
                        <p className="text-white/60 text-xs">Duration</p>
                        <p className="text-white font-semibold">{program.duration}</p>
                      </div>
                      <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                        <Users className="w-5 h-5 text-primary mb-2" />
                        <p className="text-white/60 text-xs">Participants</p>
                        <p className="text-white font-semibold text-sm">{program.participants}</p>
                      </div>
                      <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                        <Target className="w-5 h-5 text-primary mb-2" />
                        <p className="text-white/60 text-xs">Mode</p>
                        <p className="text-white font-semibold">{program.mode}</p>
                      </div>
                    </div>

                    {/* Description */}
                    <p className="text-white/70 text-lg leading-relaxed mb-8">
                      {program.description}
                    </p>

                    {/* Tabs for Different Info */}
                    <Tabs defaultValue="features" className="w-full">
                      <TabsList className="bg-white/5 border border-white/10 p-1 mb-6">
                        <TabsTrigger value="features" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                          Key Features
                        </TabsTrigger>
                        <TabsTrigger value="schedule" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                          Schedule
                        </TabsTrigger>
                        {program.streams && (
                          <TabsTrigger value="streams" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                            Tech Streams
                          </TabsTrigger>
                        )}
                        {program.phases && (
                          <TabsTrigger value="phases" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                            Phases
                          </TabsTrigger>
                        )}
                        {program.focusAreas && (
                          <TabsTrigger value="domains" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                            Focus Areas
                          </TabsTrigger>
                        )}
                        {program.tracks && (
                          <TabsTrigger value="tracks" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                            Pitch Tracks
                          </TabsTrigger>
                        )}
                      </TabsList>

                      <TabsContent value="features">
                        <div className="grid md:grid-cols-2 gap-3">
                          {program.features.map((feature, i) => (
                            <div key={i} className="flex items-start gap-3 p-3 bg-white/5 rounded-lg border border-white/10">
                              <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                              <span className="text-white/80 text-sm">{feature}</span>
                            </div>
                          ))}
                        </div>
                      </TabsContent>

                      <TabsContent value="schedule">
                        {program.schedule ? (
                          <div className="space-y-3">
                            <div className="grid md:grid-cols-2 gap-6">
                              <div>
                                <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                                  <span className="w-2 h-2 rounded-full bg-primary" />
                                  Day 1
                                </h4>
                                <div className="space-y-2">
                                  {program.schedule.filter(s => s.day === 1).map((item, i) => (
                                    <div key={i} className="flex items-center gap-3 p-3 bg-white/5 rounded-lg border border-white/10">
                                      <span className="text-primary text-xs font-mono w-24 shrink-0">{item.time}</span>
                                      <span className="text-white/80 text-sm">{item.activity}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                              <div>
                                <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                                  <span className="w-2 h-2 rounded-full bg-primary" />
                                  Day 2
                                </h4>
                                <div className="space-y-2">
                                  {program.schedule.filter(s => s.day === 2).map((item, i) => (
                                    <div key={i} className="flex items-center gap-3 p-3 bg-white/5 rounded-lg border border-white/10">
                                      <span className="text-primary text-xs font-mono w-24 shrink-0">{item.time}</span>
                                      <span className="text-white/80 text-sm">{item.activity}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </div>
                          </div>
                        ) : (
                          <p className="text-white/60">Schedule details coming soon.</p>
                        )}
                      </TabsContent>

                      {program.streams && (
                        <TabsContent value="streams">
                          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                            {program.streams.map((stream, i) => (
                              <div key={i} className="p-4 bg-white/5 rounded-xl border border-white/10 text-center">
                                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-3">
                                  <span className="text-primary font-bold">{stream.priority}</span>
                                </div>
                                <p className="text-white font-medium text-sm">{stream.name}</p>
                              </div>
                            ))}
                          </div>
                        </TabsContent>
                      )}

                      {program.phases && (
                        <TabsContent value="phases">
                          <div className="space-y-3">
                            {program.phases.map((phase, i) => (
                              <div key={i} className="flex items-start gap-4 p-4 bg-white/5 rounded-xl border border-white/10">
                                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center shrink-0">
                                  <span className="text-white font-bold text-sm">{i + 1}</span>
                                </div>
                                <div>
                                  <div className="flex items-center gap-3 mb-1">
                                    <span className="text-white font-semibold">{phase.phase}</span>
                                    <span className="text-primary text-sm">{phase.date}</span>
                                  </div>
                                  <p className="text-white/70 text-sm">{phase.activity}</p>
                                  {phase.participants && (
                                    <p className="text-white/50 text-xs mt-1">{phase.participants}</p>
                                  )}
                                  {phase.topics && (
                                    <p className="text-white/50 text-xs mt-1">Topics: {phase.topics}</p>
                                  )}
                                  {phase.prize && (
                                    <p className="text-primary font-semibold text-sm mt-1">Prize Pool: {phase.prize}</p>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </TabsContent>
                      )}

                      {program.focusAreas && (
                        <TabsContent value="domains">
                          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                            {program.focusAreas.map((area, i) => (
                              <div key={i} className="flex items-center gap-3 p-3 bg-white/5 rounded-lg border border-white/10">
                                <Cpu className="w-4 h-4 text-primary shrink-0" />
                                <span className="text-white/80 text-sm">{area}</span>
                              </div>
                            ))}
                          </div>
                          {program.venues && (
                            <div className="mt-6 grid md:grid-cols-3 gap-4">
                              {program.venues.map((venue, i) => (
                                <div key={i} className="p-4 bg-gradient-to-br from-primary/10 to-transparent rounded-xl border border-primary/20">
                                  <Building className="w-5 h-5 text-primary mb-2" />
                                  <p className="text-white font-semibold">{venue.name}</p>
                                  <p className="text-white/60 text-sm">{venue.block}</p>
                                  <p className="text-primary font-bold mt-1">{venue.capacity.toLocaleString()} seats</p>
                                </div>
                              ))}
                            </div>
                          )}
                        </TabsContent>
                      )}

                      {program.tracks && (
                        <TabsContent value="tracks">
                          <div className="grid md:grid-cols-2 gap-6">
                            {program.tracks.map((track, i) => (
                              <div key={i} className="p-6 bg-white/5 rounded-xl border border-white/10">
                                <h4 className="text-white font-semibold text-lg mb-4">{track.name}</h4>
                                <div className="space-y-3">
                                  <div className="flex justify-between">
                                    <span className="text-white/60">Total Slots</span>
                                    <span className="text-white font-semibold">{track.slots} teams</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-white/60">Pitch Duration</span>
                                    <span className="text-white font-semibold">{track.pitchDuration}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="text-white/60">Q&A Duration</span>
                                    <span className="text-white font-semibold">{track.qaDuration}</span>
                                  </div>
                                  <div className="flex justify-between border-t border-white/10 pt-3">
                                    <span className="text-white/60">Total Time</span>
                                    <span className="text-primary font-bold">{track.totalTime}</span>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </TabsContent>
                      )}
                    </Tabs>

                    {/* CTA */}
                    <div className="mt-8 pt-6 border-t border-white/10 flex flex-wrap items-center gap-4">
                      <Link
                        to="/register"
                        className="inline-flex items-center gap-2 px-6 py-3 bg-primary hover:bg-primary/90 text-white font-semibold rounded-full transition-all"
                      >
                        <Rocket className="w-4 h-4" />
                        Register Now
                      </Link>
                      <Link
                        to="/passes"
                        className="inline-flex items-center gap-2 px-6 py-3 bg-white/10 hover:bg-white/20 text-white font-medium rounded-full border border-white/20 transition-all"
                      >
                        <Trophy className="w-4 h-4" />
                        View Passes
                      </Link>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>
      </Layout>
    </>
  );
};

export default Programs;