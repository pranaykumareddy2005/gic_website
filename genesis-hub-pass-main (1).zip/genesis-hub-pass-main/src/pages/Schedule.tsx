import Layout from "@/components/layout/Layout";
import { Helmet } from "react-helmet-async";
import { Calendar, Clock, MapPin, Users, Mic, Lightbulb, Trophy, Presentation } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

const scheduleData = {
  day1: {
    date: "27 February 2026",
    events: [
      {
        time: "08:00 AM - 09:00 AM",
        title: "Registration & Check-in",
        type: "Registration",
        venue: "Main Entrance Hall",
        icon: Users,
        color: "bg-primary/10 text-primary"
      },
      {
        time: "09:00 AM - 10:00 AM",
        title: "Inaugural Ceremony",
        type: "Ceremony",
        venue: "Main Auditorium",
        icon: Mic,
        color: "bg-gic-purple/10 text-gic-purple",
        speaker: "Chief Guest & Dignitaries"
      },
      {
        time: "10:00 AM - 11:30 AM",
        title: "Keynote: Future of Deep-Tech Innovation",
        type: "Talk",
        venue: "Main Auditorium",
        icon: Presentation,
        color: "bg-accent/10 text-accent",
        speaker: "Industry Leader"
      },
      {
        time: "11:30 AM - 01:00 PM",
        title: "Knowledge Hub: Panel Discussion on Startup Ecosystem",
        type: "Panel",
        venue: "Conference Hall A",
        icon: Users,
        color: "bg-gic-orange/10 text-gic-orange",
        speaker: "Multiple Experts"
      },
      {
        time: "01:00 PM - 02:00 PM",
        title: "Networking Lunch",
        type: "Break",
        venue: "Food Court",
        icon: Users,
        color: "bg-muted text-muted-foreground"
      },
      {
        time: "02:00 PM - 04:00 PM",
        title: "BusiTech Expo: Startup Showcases",
        type: "Expo",
        venue: "Exhibition Hall",
        icon: Lightbulb,
        color: "bg-gic-green/10 text-gic-green"
      },
      {
        time: "04:00 PM - 06:00 PM",
        title: "Alpha to Infinite: Innovation Challenge Round 1",
        type: "Competition",
        venue: "Innovation Labs",
        icon: Trophy,
        color: "bg-gic-purple/10 text-gic-purple"
      },
      {
        time: "06:00 PM - 07:00 PM",
        title: "Masterminds Congregation: School Innovators",
        type: "Activity",
        venue: "Hall B",
        icon: Lightbulb,
        color: "bg-primary/10 text-primary"
      }
    ]
  },
  day2: {
    date: "28 February 2026",
    events: [
      {
        time: "09:00 AM - 10:30 AM",
        title: "Investors Boot Camp: Pitching Session Round 1",
        type: "Pitching",
        venue: "Main Auditorium",
        icon: Presentation,
        color: "bg-gic-orange/10 text-gic-orange"
      },
      {
        time: "10:30 AM - 12:00 PM",
        title: "Knowledge Hub: AI & Quantum Computing",
        type: "Talk",
        venue: "Conference Hall A",
        icon: Mic,
        color: "bg-accent/10 text-accent",
        speaker: "Tech Experts"
      },
      {
        time: "12:00 PM - 01:00 PM",
        title: "Student Innovation Expo",
        type: "Expo",
        venue: "Exhibition Hall",
        icon: Lightbulb,
        color: "bg-gic-green/10 text-gic-green"
      },
      {
        time: "01:00 PM - 02:00 PM",
        title: "Networking Lunch",
        type: "Break",
        venue: "Food Court",
        icon: Users,
        color: "bg-muted text-muted-foreground"
      },
      {
        time: "02:00 PM - 04:00 PM",
        title: "Investors Boot Camp: Final Pitching Round",
        type: "Pitching",
        venue: "Main Auditorium",
        icon: Trophy,
        color: "bg-gic-orange/10 text-gic-orange"
      },
      {
        time: "04:00 PM - 05:00 PM",
        title: "Alpha to Infinite: Innovation Challenge Finals",
        type: "Competition",
        venue: "Innovation Labs",
        icon: Trophy,
        color: "bg-gic-purple/10 text-gic-purple"
      },
      {
        time: "05:00 PM - 06:00 PM",
        title: "Valedictory Ceremony & Awards",
        type: "Ceremony",
        venue: "Main Auditorium",
        icon: Trophy,
        color: "bg-primary/10 text-primary",
        speaker: "Chief Guest"
      },
      {
        time: "06:00 PM - 07:00 PM",
        title: "Closing & Networking",
        type: "Networking",
        venue: "Main Hall",
        icon: Users,
        color: "bg-accent/10 text-accent"
      }
    ]
  }
};

const Schedule = () => {
  return (
    <>
      <Helmet>
        <title>Event Schedule - GIC 2026</title>
        <meta name="description" content="View the complete schedule for Global Innovators Conclave 2026. Day-wise breakdown of sessions, talks, workshops, and activities." />
      </Helmet>
      <Layout>
        {/* Hero Section */}
        <section className="bg-hero-gradient py-16 md:py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto">
              <Badge className="bg-primary/10 text-primary border-0 mb-4">
                <Calendar className="w-3 h-3 mr-1" />
                Event Schedule
              </Badge>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
                Event <span className="text-gradient-blue">Schedule</span>
              </h1>
              <p className="text-muted-foreground text-lg">
                Two days of innovation, collaboration, and discovery. Plan your GIC 2026 experience.
              </p>
            </div>
          </div>
        </section>

        {/* Schedule Tabs */}
        <section className="py-12 md:py-16">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <Tabs defaultValue="day1" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-8 h-auto p-1 bg-muted/50">
                <TabsTrigger value="day1" className="py-3 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                  <div className="text-center">
                    <div className="font-semibold">Day 1</div>
                    <div className="text-xs opacity-80">27 Feb 2026</div>
                  </div>
                </TabsTrigger>
                <TabsTrigger value="day2" className="py-3 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                  <div className="text-center">
                    <div className="font-semibold">Day 2</div>
                    <div className="text-xs opacity-80">28 Feb 2026</div>
                  </div>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="day1" className="space-y-4">
                {scheduleData.day1.events.map((event, index) => (
                  <div key={index} className="bg-card border border-border rounded-xl p-4 md:p-6 card-hover">
                    <div className="flex flex-col md:flex-row md:items-center gap-4">
                      <div className={`w-12 h-12 rounded-xl ${event.color} flex items-center justify-center shrink-0`}>
                        <event.icon className="w-6 h-6" />
                      </div>
                      <div className="flex-1">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <Badge variant="outline" className="text-xs">
                            {event.type}
                          </Badge>
                          <span className="text-sm text-muted-foreground flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {event.time}
                          </span>
                        </div>
                        <h3 className="font-semibold text-foreground text-lg">{event.title}</h3>
                        {event.speaker && (
                          <p className="text-sm text-muted-foreground mt-1">Speaker: {event.speaker}</p>
                        )}
                      </div>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <MapPin className="w-4 h-4" />
                        {event.venue}
                      </div>
                    </div>
                  </div>
                ))}
              </TabsContent>

              <TabsContent value="day2" className="space-y-4">
                {scheduleData.day2.events.map((event, index) => (
                  <div key={index} className="bg-card border border-border rounded-xl p-4 md:p-6 card-hover">
                    <div className="flex flex-col md:flex-row md:items-center gap-4">
                      <div className={`w-12 h-12 rounded-xl ${event.color} flex items-center justify-center shrink-0`}>
                        <event.icon className="w-6 h-6" />
                      </div>
                      <div className="flex-1">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <Badge variant="outline" className="text-xs">
                            {event.type}
                          </Badge>
                          <span className="text-sm text-muted-foreground flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {event.time}
                          </span>
                        </div>
                        <h3 className="font-semibold text-foreground text-lg">{event.title}</h3>
                        {event.speaker && (
                          <p className="text-sm text-muted-foreground mt-1">Speaker: {event.speaker}</p>
                        )}
                      </div>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <MapPin className="w-4 h-4" />
                        {event.venue}
                      </div>
                    </div>
                  </div>
                ))}
              </TabsContent>
            </Tabs>

            {/* Note */}
            <div className="mt-8 p-4 bg-primary/5 border border-primary/20 rounded-xl">
              <p className="text-sm text-muted-foreground text-center">
                <strong>Note:</strong> Schedule is subject to change. Check announcements for updates.
              </p>
            </div>
          </div>
        </section>
      </Layout>
    </>
  );
};

export default Schedule;
