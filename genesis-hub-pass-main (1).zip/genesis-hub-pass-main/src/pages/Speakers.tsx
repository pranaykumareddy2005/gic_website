import Layout from "@/components/layout/Layout";
import { Helmet } from "react-helmet-async";
import { Mic, Linkedin, Twitter, Globe } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const speakers = [
  {
    name: "Dr. Rajesh Kumar",
    designation: "CEO, TechVentures India",
    expertise: "Startup Ecosystem",
    session: "Keynote: Future of Deep-Tech Innovation",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&h=300&fit=crop&crop=face",
    linkedin: "#",
    twitter: "#"
  },
  {
    name: "Dr. Priya Sharma",
    designation: "Director, NITI Aayog",
    expertise: "Policy & Innovation",
    session: "Panel: Government Initiatives for Startups",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=300&h=300&fit=crop&crop=face",
    linkedin: "#",
    twitter: "#"
  },
  {
    name: "Arun Venkatesh",
    designation: "Partner, Sequoia Capital India",
    expertise: "Venture Capital",
    session: "Investors Boot Camp: What VCs Look For",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=300&fit=crop&crop=face",
    linkedin: "#",
    twitter: "#"
  },
  {
    name: "Dr. Meera Rao",
    designation: "Head of AI, Microsoft India",
    expertise: "Artificial Intelligence",
    session: "Knowledge Hub: AI & Quantum Computing",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300&h=300&fit=crop&crop=face",
    linkedin: "#",
    twitter: "#"
  },
  {
    name: "Vikram Singh",
    designation: "Founder, SpaceTech Innovations",
    expertise: "Space Technology",
    session: "Deep-Tech: India's Space Revolution",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=300&h=300&fit=crop&crop=face",
    linkedin: "#",
    twitter: "#"
  },
  {
    name: "Dr. Ananya Patel",
    designation: "Professor, IIT Hyderabad",
    expertise: "Biotechnology",
    session: "Research to Startup: Bridging the Gap",
    image: "https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?w=300&h=300&fit=crop&crop=face",
    linkedin: "#",
    twitter: "#"
  },
  {
    name: "Karthik Reddy",
    designation: "Co-founder, Blume Ventures",
    expertise: "Early Stage Investing",
    session: "Investors Boot Camp: Seed to Series A",
    image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=300&h=300&fit=crop&crop=face",
    linkedin: "#",
    twitter: "#"
  },
  {
    name: "Sunita Krishnan",
    designation: "CTO, Infosys",
    expertise: "Digital Transformation",
    session: "Enterprise Innovation & Technology",
    image: "https://images.unsplash.com/photo-1598550874175-4d0ef436c909?w=300&h=300&fit=crop&crop=face",
    linkedin: "#",
    twitter: "#"
  }
];

const Speakers = () => {
  return (
    <>
      <Helmet>
        <title>Speakers - GIC 2026</title>
        <meta name="description" content="Meet the industry leaders, innovators, and experts speaking at Global Innovators Conclave 2026." />
      </Helmet>
      <Layout>
        {/* Hero Section */}
        <section className="bg-hero-gradient py-16 md:py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto">
              <Badge className="bg-primary/10 text-primary border-0 mb-4">
                <Mic className="w-3 h-3 mr-1" />
                Expert Speakers
              </Badge>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
                Meet Our <span className="text-gradient-blue">Speakers</span>
              </h1>
              <p className="text-muted-foreground text-lg">
                Learn from industry leaders, policymakers, investors, and innovators shaping the future of technology.
              </p>
            </div>
          </div>
        </section>

        {/* Speakers Grid */}
        <section className="py-12 md:py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {speakers.map((speaker, index) => (
                <div 
                  key={index}
                  className="bg-card border border-border rounded-xl overflow-hidden card-hover group"
                >
                  <div className="relative">
                    <img 
                      src={speaker.image} 
                      alt={speaker.name}
                      className="w-full h-64 object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    <div className="absolute bottom-4 left-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <a href={speaker.linkedin} className="w-8 h-8 bg-white/90 rounded-full flex items-center justify-center hover:bg-white transition-colors">
                        <Linkedin className="w-4 h-4 text-primary" />
                      </a>
                      <a href={speaker.twitter} className="w-8 h-8 bg-white/90 rounded-full flex items-center justify-center hover:bg-white transition-colors">
                        <Twitter className="w-4 h-4 text-primary" />
                      </a>
                    </div>
                  </div>
                  <div className="p-4">
                    <Badge variant="outline" className="text-xs mb-2">
                      {speaker.expertise}
                    </Badge>
                    <h3 className="font-semibold text-foreground text-lg">{speaker.name}</h3>
                    <p className="text-sm text-muted-foreground mb-3">{speaker.designation}</p>
                    <div className="pt-3 border-t border-border">
                      <p className="text-xs text-primary font-medium">{speaker.session}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* More Speakers Coming */}
            <div className="mt-12 text-center">
              <div className="inline-flex items-center gap-2 px-6 py-3 bg-primary/5 rounded-full">
                <Globe className="w-5 h-5 text-primary" />
                <span className="text-muted-foreground">More speakers to be announced soon!</span>
              </div>
            </div>
          </div>
        </section>
      </Layout>
    </>
  );
};

export default Speakers;
