import Layout from "@/components/layout/Layout";
import { Helmet } from "react-helmet-async";
import { MapPin, Navigation, Car, Train, Plane, Phone, Mail, Clock, Building } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const venueDetails = {
  name: "St. Martin's Engineering College",
  address: "Dhulapally, Secunderabad, Telangana 500100",
  coordinates: { lat: 17.5449, lng: 78.3866 },
  halls: [
    { name: "Main Auditorium", capacity: "1500+ seats", purpose: "Keynotes, Ceremonies" },
    { name: "Conference Hall A", capacity: "500 seats", purpose: "Panel Discussions, Talks" },
    { name: "Exhibition Hall", capacity: "100+ stalls", purpose: "BusiTech Expo" },
    { name: "Innovation Labs", capacity: "300 participants", purpose: "Alpha to Infinite Challenge" },
    { name: "Hall B", capacity: "200 seats", purpose: "Masterminds Congregation" }
  ]
};

const transportOptions = [
  {
    icon: Plane,
    title: "By Air",
    description: "Rajiv Gandhi International Airport (HYD) is approximately 45 km away. Cabs and airport shuttles are available.",
    time: "~60 minutes"
  },
  {
    icon: Train,
    title: "By Train",
    description: "Secunderabad Railway Station is approximately 15 km away. Auto-rickshaws and cabs are easily available.",
    time: "~30 minutes"
  },
  {
    icon: Car,
    title: "By Road",
    description: "Well connected via NH44. Located near Kompally, easily accessible from all parts of Hyderabad.",
    time: "Varies"
  }
];

const Venue = () => {
  return (
    <>
      <Helmet>
        <title>Venue - GIC 2026</title>
        <meta name="description" content="Find venue details, directions, and hall information for Global Innovators Conclave 2026 at St. Martin's Engineering College, Hyderabad." />
      </Helmet>
      <Layout>
        {/* Hero Section */}
        <section className="bg-hero-gradient py-16 md:py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto">
              <Badge className="bg-primary/10 text-primary border-0 mb-4">
                <MapPin className="w-3 h-3 mr-1" />
                Event Venue
              </Badge>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
                Venue <span className="text-gradient-blue">Information</span>
              </h1>
              <p className="text-muted-foreground text-lg">
                Join us at St. Martin's Engineering College, Hyderabad - A premier institution for innovation and learning.
              </p>
            </div>
          </div>
        </section>

        {/* Venue Details */}
        <section className="py-12 md:py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-8 mb-12">
              {/* Map Placeholder */}
              <div className="bg-muted rounded-xl overflow-hidden h-80 lg:h-full min-h-[320px] relative">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3804.5!2d78.3866!3d17.5449!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTfCsDMyJzQxLjYiTiA3OMKwMjMnMTEuOCJF!5e0!3m2!1sen!2sin!4v1234567890"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="absolute inset-0"
                />
              </div>

              {/* Venue Info */}
              <div className="space-y-6">
                <div className="bg-card border border-border rounded-xl p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center shrink-0">
                      <Building className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h2 className="text-xl font-bold text-foreground mb-2">{venueDetails.name}</h2>
                      <p className="text-muted-foreground mb-4">{venueDetails.address}</p>
                      <a 
                        href={`https://www.google.com/maps/dir/?api=1&destination=${venueDetails.coordinates.lat},${venueDetails.coordinates.lng}`}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <Button className="gap-2">
                          <Navigation className="w-4 h-4" />
                          Get Directions
                        </Button>
                      </a>
                    </div>
                  </div>
                </div>

                {/* Contact */}
                <div className="bg-card border border-border rounded-xl p-6">
                  <h3 className="font-semibold text-foreground mb-4">Venue Contact</h3>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 text-muted-foreground">
                      <Phone className="w-4 h-4 text-primary" />
                      <span>+91 40 2754 1234</span>
                    </div>
                    <div className="flex items-center gap-3 text-muted-foreground">
                      <Mail className="w-4 h-4 text-primary" />
                      <span>gic2026@smec.ac.in</span>
                    </div>
                    <div className="flex items-center gap-3 text-muted-foreground">
                      <Clock className="w-4 h-4 text-primary" />
                      <span>Event Days: 8:00 AM - 7:00 PM</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Halls & Facilities */}
            <div className="mb-12">
              <h2 className="text-2xl font-bold text-foreground mb-6 text-center">Event Halls & Facilities</h2>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {venueDetails.halls.map((hall, index) => (
                  <div key={index} className="bg-card border border-border rounded-xl p-5 card-hover">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                        <MapPin className="w-5 h-5 text-primary" />
                      </div>
                      <h3 className="font-semibold text-foreground">{hall.name}</h3>
                    </div>
                    <p className="text-sm text-muted-foreground mb-1">Capacity: {hall.capacity}</p>
                    <p className="text-sm text-primary">{hall.purpose}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* How to Reach */}
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-6 text-center">How to Reach</h2>
              <div className="grid md:grid-cols-3 gap-6">
                {transportOptions.map((option, index) => (
                  <div key={index} className="bg-card border border-border rounded-xl p-6 card-hover">
                    <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center mb-4">
                      <option.icon className="w-6 h-6 text-accent" />
                    </div>
                    <h3 className="font-semibold text-foreground mb-2">{option.title}</h3>
                    <p className="text-sm text-muted-foreground mb-3">{option.description}</p>
                    <Badge variant="outline">{option.time}</Badge>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      </Layout>
    </>
  );
};

export default Venue;
